package com.openclassrooms.testing.calcul.service;

public interface SolutionFormatter {
	String format(int solution);
}
